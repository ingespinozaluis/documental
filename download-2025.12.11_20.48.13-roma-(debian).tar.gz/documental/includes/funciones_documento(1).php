<?php
// includes/funciones_documento.php
// Contiene funciones para interactuar con las tablas documento, categoria, solicitud e historial.

require_once __DIR__ . '/../config/db.php'; 

// =========================================================================
// FUNCIONES DE HISTORIAL (AUDITORÍA)
// =========================================================================

/**
 * Registra una acción en la tabla Historial.
 */
function registrarHistorial($idUsuario, $idDocumento, $accion) {
    $conexion = conectarDB();
    $fecha = date("Y-m-d H:i:s"); // Usamos DATETIME

    $stmt = $conexion->prepare("INSERT INTO historial (idUsuario, idDocumento, accion, fecha) VALUES (?, ?, ?, ?)");
    
    if (!$stmt) {
        error_log("Error al preparar la consulta de historial: " . $conexion->error);
        $conexion->close();
        return false;
    }

    $stmt->bind_param("iiss", $idUsuario, $idDocumento, $accion, $fecha);
    
    $exito = $stmt->execute();
    
    if (!$exito) {
        error_log("Error al ejecutar el registro de historial: " . $stmt->error);
    }
    
    $stmt->close();
    $conexion->close();
    return $exito;
}

/**
 * Obtiene el historial completo de actividades.
 */
function obtenerHistorialCompleto() {
    $conexion = conectarDB();
    $historial = [];
    
    $sql = "SELECT 
                h.idHistorial, 
                h.accion, 
                h.fecha, 
                u.nombre AS usuario, 
                d.titulo AS documento_titulo
            FROM historial h
            JOIN usuario u ON h.idUsuario = u.idUsuario
            LEFT JOIN documento d ON h.idDocumento = d.idDocumento
            ORDER BY h.fecha DESC";
            
    $resultado = $conexion->query($sql);

    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $historial[] = $fila;
        }
    }
    $conexion->close();
    return $historial;
}


// =========================================================================
// FUNCIONES DE DOCUMENTOS Y CATEGORÍAS
// =========================================================================

/**
 * Obtiene todas las categorías para el formulario de clasificación.
 */
function obtenerCategorias() {
    $conexion = conectarDB();
    $sql = "SELECT idCategoria, nombre FROM categoria ORDER BY nombre";
    $resultado = $conexion->query($sql);
    
    $categorias = [];
    if ($resultado && $resultado->num_rows > 0) {
        while($fila = $resultado->fetch_assoc()) {
            $categorias[] = $fila;
        }
    }
    $conexion->close();
    return $categorias;
}


/**
 * Sube los metadatos del documento a la DB y registra el historial.
 * Estado inicial es 'Aprobado'.
 */
function subirDocumentoDB($titulo, $idUsuario, $idCategoria, $rutaArchivo) {
    $conexion = conectarDB();
    $fechaSubida = date("Y-m-d"); 
    $estado = 'Aprobado';

    $stmt = $conexion->prepare("INSERT INTO documento 
                                (titulo, fechaSubida, estado, idUsuario, idCategoria, rutaArchivo) 
                                VALUES (?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        error_log("Error al preparar subirDocumentoDB: " . $conexion->error);
        $conexion->close();
        return false;
    }

    $stmt->bind_param("sssiis", $titulo, $fechaSubida, $estado, $idUsuario, $idCategoria, $rutaArchivo);
    
    $exito = $stmt->execute();
    
    if ($exito) {
        $idDocumento = $conexion->insert_id;
        $accion_historial = "Documento '{$titulo}' subido, clasificado (ID Cat: {$idCategoria}) y aprobado.";
        registrarHistorial($idUsuario, $idDocumento, $accion_historial);
    } else {
        error_log("Error al ejecutar subirDocumentoDB: " . $stmt->error);
    }

    $stmt->close();
    $conexion->close();
    return $exito;
}

/**
 * Busca y lista documentos para su visualización o solicitud.
 */
function buscarDocumentos($termino, $rol) {
    $conexion = conectarDB();
    $documentos = [];
    $where = "WHERE d.titulo LIKE ? AND d.estado = 'Aprobado'"; // Solo documentos aprobados son visibles
    $param_type = "s";
    $param_value = "%" . $termino . "%";
    
    $sql = "SELECT 
                d.idDocumento, d.titulo, d.fechaSubida, d.estado, d.rutaArchivo, c.nombre AS categoria, u.nombre AS usuarioSubio
            FROM documento d
            JOIN categoria c ON d.idCategoria = c.idCategoria
            JOIN usuario u ON d.idUsuario = u.idUsuario
            " . $where;
    
    $stmt = $conexion->prepare($sql);
    
    if (!$stmt) {
        error_log("Error al preparar buscarDocumentos: " . $conexion->error);
        $conexion->close();
        return $documentos;
    }
    
    $stmt->bind_param($param_type, $param_value);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($fila = $resultado->fetch_assoc()) {
        $documentos[] = $fila;
    }

    $stmt->close();
    $conexion->close();
    return $documentos;
}


// =========================================================================
// FUNCIONES DE SOLICITUDES
// =========================================================================

/**
 * Registra una solicitud de documento. (Caso de Uso: Solicitar Documento)
 */
function solicitarDocumento($idDocumento, $idUsuario) {
    $conexion = conectarDB();
    $fecha = date("Y-m-d");
    $estado = 'Pendiente';
    
    // Verificar si ya existe una solicitud pendiente
    $stmt_check = $conexion->prepare("SELECT idSolicitud FROM solicitud WHERE idDocumento = ? AND idUsuario = ? AND estado = 'Pendiente'");
    $stmt_check->bind_param("ii", $idDocumento, $idUsuario);
    $stmt_check->execute();
    $stmt_check->store_result();
    
    if ($stmt_check->num_rows > 0) {
        $stmt_check->close();
        $conexion->close();
        return false; // Ya existe una solicitud pendiente
    }
    $stmt_check->close();
    
    $stmt = $conexion->prepare("INSERT INTO solicitud (idDocumento, idUsuario, fecha, estado) VALUES (?, ?, ?, ?)");
    
    if (!$stmt) {
        error_log("Error al preparar solicitarDocumento: " . $conexion->error);
        $conexion->close();
        return false;
    }

    $stmt->bind_param("iiss", $idDocumento, $idUsuario, $fecha, $estado);
    
    $exito = $stmt->execute();
    
    if ($exito) {
        $accion = "Solicitud de acceso a documento ID: {$idDocumento} registrada.";
        registrarHistorial($idUsuario, $idDocumento, $accion);
    }
    
    $stmt->close();
    $conexion->close();
    return $exito;
}

/**
 * Lista todas las solicitudes pendientes para que el Archivista las gestione.
 */
function obtenerSolicitudesPendientes() {
    $conexion = conectarDB();
    $solicitudes = [];
    
    $sql = "SELECT 
                s.idSolicitud, s.idDocumento, s.fecha, s.estado, 
                u.nombre AS solicitante, 
                d.titulo AS documento
            FROM solicitud s
            JOIN usuario u ON s.idUsuario = u.idUsuario
            JOIN documento d ON s.idDocumento = d.idDocumento
            WHERE s.estado = 'Pendiente'
            ORDER BY s.fecha ASC";
            
    $resultado = $conexion->query($sql);

    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $solicitudes[] = $fila;
        }
    }
    $conexion->close();
    return $solicitudes;
}

/**
 * Aprueba o rechaza una solicitud y registra la acción en el historial. 
 */
function gestionarSolicitud($idSolicitud, $nuevoEstado, $idUsuarioGestor) { 
    $conexion = conectarDB();
    
    // 1. Obtener el ID del documento antes de la actualización
    $stmt_fetch = $conexion->prepare("SELECT idDocumento FROM solicitud WHERE idSolicitud = ?");
    $stmt_fetch->bind_param("i", $idSolicitud);
    $stmt_fetch->execute();
    $resultado = $stmt_fetch->get_result();
    $solicitud_data = $resultado->fetch_assoc();
    $stmt_fetch->close();

    $idDocumento = $solicitud_data['idDocumento'] ?? null;
    
    if (!$idDocumento) {
        $conexion->close();
        return false;
    }
    
    // 2. Actualizar el estado de la solicitud
    $stmt = $conexion->prepare("UPDATE solicitud SET estado = ? WHERE idSolicitud = ?");
    $stmt->bind_param("si", $nuevoEstado, $idSolicitud);
    
    $exito = $stmt->execute();
    
    // 3. Registrar en Historial si la actualización fue exitosa
    if ($exito) {
        $accion = "Solicitud ID: {$idSolicitud} fue '{$nuevoEstado}' por el Archivista.";
        registrarHistorial($idUsuarioGestor, $idDocumento, $accion);
    }

    $stmt->close();
    $conexion->close();
    return $exito;
}

/**
 * Obtiene todas las solicitudes enviadas por un usuario específico (Secretaria/Externo).
 */
function obtenerSolicitudesPorUsuario($idUsuario) {
    $conexion = conectarDB();
    $solicitudes = [];
    
    $sql = "SELECT 
                s.idSolicitud, 
                s.fecha, 
                s.estado, 
                d.titulo AS documento_titulo, 
                d.rutaArchivo 
            FROM solicitud s
            JOIN documento d ON s.idDocumento = d.idDocumento
            WHERE s.idUsuario = ?
            ORDER BY s.fecha DESC";
            
    $stmt = $conexion->prepare($sql);
    
    if (!$stmt) {
        error_log("Error al preparar obtenerSolicitudesPorUsuario: " . $conexion->error);
        $conexion->close();
        return $solicitudes;
    }
    
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($fila = $resultado->fetch_assoc()) {
        $solicitudes[] = $fila;
    }

    $stmt->close();
    $conexion->close();
    return $solicitudes;
}

/**
 * Obtiene los detalles de una solicitud específica por su ID.
 * Usada por el script de descarga segura.
 */
function obtenerDetallesSolicitud($idSolicitud) {
    $conexion = conectarDB();
    $solicitud = null;
    
    $sql = "SELECT 
                s.idSolicitud, 
                s.idUsuario, 
                s.estado, 
                d.rutaArchivo,
                d.titulo
            FROM solicitud s
            JOIN documento d ON s.idDocumento = d.idDocumento
            WHERE s.idSolicitud = ?";
            
    $stmt = $conexion->prepare($sql);
    
    if (!$stmt) {
        error_log("Error al preparar obtenerDetallesSolicitud: " . $conexion->error);
        $conexion->close();
        return null;
    }
    
    $stmt->bind_param("i", $idSolicitud);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $solicitud = $resultado->fetch_assoc();
    }

    $stmt->close();
    $conexion->close();
    return $solicitud;
}