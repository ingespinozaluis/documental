<?php
// includes/funciones_usuario.php

// Incluir el archivo de conexión si aún no está
require_once __DIR__ . '/../config/db.php'; 

/**
 * Registra un nuevo usuario en la base de datos.
 */
function registrarUsuario($nombre, $correo, $password, $rol) {
    $conexion = conectarDB();
    
    // 1. Cifrar la contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // 2. Preparar la consulta SQL para evitar inyección (Prepared Statements)
    $stmt = $conexion->prepare("INSERT INTO usuario (nombre, correo, password_hash, rol) VALUES (?, ?, ?, ?)");
    
    // 3. Vincular parámetros
    $stmt->bind_param("ssss", $nombre, $correo, $password_hash, $rol);
    
    // 4. Ejecutar la consulta
    if ($stmt->execute()) {
        $stmt->close();
        $conexion->close();
        return true;
    } else {
        // En un entorno real, manejar el error (e.g., correo duplicado)
        echo "Error al registrar: " . $stmt->error;
        $stmt->close();
        $conexion->close();
        return false;
    }
}

/**
 * Inicia la sesión de un usuario.
 */
function iniciarSesion($correo, $password) {
    $conexion = conectarDB();
    
    // 1. Buscar al usuario por correo
    $stmt = $conexion->prepare("SELECT idUsuario, nombre, password_hash, rol FROM usuario WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        
        // 2. Verificar la contraseña cifrada
        if (password_verify($password, $usuario['password_hash'])) {
            // 3. La contraseña es correcta: iniciar la sesión
            session_start();
            $_SESSION['usuario_id'] = $usuario['idUsuario'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_rol'] = $usuario['rol'];
            
            $stmt->close();
            $conexion->close();
            return true;
        }
    }
    
    $stmt->close();
    $conexion->close();
    return false; // Credenciales inválidas
}

/**
 * Función para verificar si un usuario tiene un rol específico.
 */
function verificarRol($rol_requerido) {
    // Asegurar que la sesión está iniciada
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== $rol_requerido) {
        return false;
    }
    return true;
}