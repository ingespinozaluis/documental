<?php
// login.php
require_once 'includes/funciones_usuario.php';

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (iniciarSesion($correo, $password)) {
        // Redirigir según el rol
        $rol = $_SESSION['usuario_rol'];
        
        if ($rol === 'Administrador') {
            header('Location: dashboard/admin.php');
        } elseif ($rol === 'Archivista') {
            header('Location: dashboard/archivista.php');
        } elseif ($rol === 'Secretaria') {
            header('Location: dashboard/secretaria.php');
        } else {
             // Cubrir el caso de 'Usuario Externo' o roles desconocidos
             header('Location: dashboard/buscar.php'); 
        }
        exit();
    } else {
        $mensaje = "Credenciales incorrectas o usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - Gestión Documental</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>
    
    <?php if ($mensaje): ?>
        <p style="color: red;"><?php echo $mensaje; ?></p>
    <?php endif; ?>
    
    <form method="POST" action="login.php">
        <label for="correo">Correo:</label>
        <input type="email" id="correo" name="correo" required><br><br>
        
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br><br>
        
        <button type="submit">Acceder</button>
    </form>
</body>
</html>