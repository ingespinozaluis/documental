<?php
// dashboard/admin.php
session_start();
require_once __DIR__ . '/../includes/funciones_usuario.php';
require_once __DIR__ . '/../includes/funciones_admin.php'; 
require_once __DIR__ . '/../includes/funciones_documento.php'; // Para el link al historial

if (!verificarRol('Administrador')) {
    header('Location: ../login.php');
    exit();
}

$idUsuarioActual = $_SESSION['usuario_id'];
$mensaje = '';
$roles_validos = ['Administrador', 'Archivista', 'Secretaria', 'Usuario Externo'];

// --- L�GICA DE EDICI�N ---
$usuario_a_editar = null;
$es_edicion = false;
$edit_id = $_GET['edit_id'] ?? 0;

if ($edit_id > 0) {
    $usuario_a_editar = obtenerUsuarioPorId($edit_id);
    if ($usuario_a_editar) {
        $es_edicion = true;
    }
}

// --- L�GICA DE ADMINISTRAR USUARIOS (CRUD) ---

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Manejo de Creaci�n/Edici�n
    if (isset($_POST['accion']) && $_POST['accion'] === 'guardar_usuario') {
        $idUsuario = $_POST['idUsuario'] ?? 0;
        $nombre = $_POST['nombre'] ?? '';
        $correo = $_POST['correo'] ?? '';
        $rol = $_POST['rol'] ?? '';
        $password = $_POST['password'] ?? null;
        
        $accion_texto = $idUsuario > 0 ? 'actualizado' : 'creado';

        if (guardarUsuario($idUsuario, $nombre, $correo, $rol, $password)) {
            $mensaje = "<p class='success'>Usuario '{$nombre}' {$accion_texto} con �xito.</p>";
            // Limpiar el modo edici�n despu�s de guardar
            $es_edicion = false;
            $usuario_a_editar = null;
            $edit_id = 0;
            // Redirigir para limpiar el par�metro GET si estaba en modo edici�n
            if (isset($_GET['edit_id'])) {
                header('Location: admin.php');
                exit();
            }
        } else {
            $mensaje = "<p class='error'>Error al guardar usuario. Verifique datos, contrase�a, y que el correo no est� duplicado.</p>";
        }
    }

    // 2. Manejo de Eliminaci�n
    if (isset($_POST['accion']) && $_POST['accion'] === 'eliminar_usuario') {
        $idUsuario = $_POST['idUsuario'];
        
        if (eliminarUsuario($idUsuario)) {
            $mensaje = "<p class='success'>Usuario ID {$idUsuario} eliminado con �xito.</p>";
        } else {
            $mensaje = "<p class='error'>Error al eliminar usuario. No se puede eliminar al usuario activo o no existe.</p>";
        }
    }
}

// Recargar la lista de usuarios al final de cualquier acci�n POST
$usuarios = obtenerUsuarios();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administrador</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; }
        .container { max-width: 1100px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1, h2 { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 20px; }
        .success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px; border-radius: 4px; }
        .error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #007bff; color: white; }
        .form-inline > * { margin-right: 10px; margin-bottom: 10px; }
        form input, form select { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .btn-edit { background-color: #ffc107; color: #333; text-decoration: none; padding: 5px 10px; border-radius: 4px; margin-right: 5px; }
        .btn-delete { background-color: #dc3545; color: white; padding: 5px 10px; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Panel de Administrador ?</h1>
        <p>Usuario Activo: <strong><?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?></strong></p>
        
        <?php echo $mensaje; ?>
        
        <h2>? <?php echo $es_edicion ? 'Editar Usuario: ' . htmlspecialchars($usuario_a_editar['nombre']) : 'Crear Nuevo Usuario'; ?></h2>
        
        <form method="POST" action="admin.php" class="form-inline">
            <input type="hidden" name="accion" value="guardar_usuario">
            <input type="hidden" name="idUsuario" value="<?php echo $es_edicion ? $usuario_a_editar['idUsuario'] : 0; ?>">
            
            <input type="text" name="nombre" placeholder="Nombre" required 
                   value="<?php echo $es_edicion ? htmlspecialchars($usuario_a_editar['nombre']) : ''; ?>">
            
            <input type="email" name="correo" placeholder="Correo" required 
                   value="<?php echo $es_edicion ? htmlspecialchars($usuario_a_editar['correo']) : ''; ?>">
            
            <input type="password" name="password" 
                   placeholder="<?php echo $es_edicion ? 'Contrase�a (Dejar vac�o para no cambiar)' : 'Contrase�a (Requerida)'; ?>"
                   <?php echo $es_edicion ? '' : 'required'; ?>>
            
            <select name="rol" required>
                <option value="">Seleccione Rol</option>
                <?php foreach ($roles_validos as $rol): ?>
                    <option value="<?php echo htmlspecialchars($rol); ?>" 
                            <?php echo ($es_edicion && $usuario_a_editar['rol'] === $rol) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($rol); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <button type="submit" style="background-color: #28a745; color: white;">
                <?php echo $es_edicion ? 'Guardar Cambios' : 'Crear Usuario'; ?>
            </button>
            
            <?php if ($es_edicion): ?>
                <a href="admin.php" style="color: #dc3545;">Cancelar Edici�n</a>
            <?php endif; ?>
        </form>

        <hr>

        <h2>? Listado de Usuarios Registrados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $user): ?>
                    <tr>
                        <td><?php echo $user['idUsuario']; ?></td>
                        <td><?php echo htmlspecialchars($user['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($user['correo']); ?></td>
                        <td><strong><?php echo htmlspecialchars($user['rol']); ?></strong></td>
                        <td>
                            <a href="admin.php?edit_id=<?php echo $user['idUsuario']; ?>" class="btn-edit">Editar</a>
                            
                            <?php if ((int)$user['idUsuario'] !== (int)$idUsuarioActual): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('�Seguro que desea eliminar a este usuario? Esta acci�n es irreversible.');">
                                    <input type="hidden" name="accion" value="eliminar_usuario">
                                    <input type="hidden" name="idUsuario" value="<?php echo $user['idUsuario']; ?>">
                                    <button type="submit" class="btn-delete">Eliminar</button>
                                </form>
                            <?php else: ?>
                                <span style="color: blue;">(Usted)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <hr>
        
        <h2>? Funcionalidades Adicionales</h2>
        <p>
            <a href="historial.php" style="padding: 5px 10px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">Ver Historial de Actividad</a> 
            (Caso de Uso: Generar Reportes / Auditor�a)
        </p>

        <p style="margin-top: 20px;"><a href="../logout.php" style="color: #dc3545;">Cerrar Sesi�n</a></p>
    </div>
</body>
</html>