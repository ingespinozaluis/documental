<?php
// dashboard/secretaria.php
session_start();
require_once __DIR__ . '/../includes/funciones_usuario.php';
require_once __DIR__ . '/../includes/funciones_documento.php';

if (!verificarRol('Secretaria') && !verificarRol('Usuario Externo')) {
    header('Location: ../login.php');
    exit();
}

$terminoBusqueda = $_GET['termino'] ?? '';
$documentos = [];
$mensaje = '';
$rol = $_SESSION['usuario_rol'];

// Búsqueda (Caso de Uso: Buscar Documento)
if (!empty($terminoBusqueda)) {
    $documentos = buscarDocumentos($terminoBusqueda, $rol);
}

// Solicitud (Caso de Uso: Solicitar Documento)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['solicitar_doc'])) {
    $idDocumento = $_POST['idDocumento'];
    $idUsuario = $_SESSION['usuario_id'];
    
    if (solicitarDocumento($idDocumento, $idUsuario)) {
        $mensaje = "<p style='color: green;'>✅ Solicitud enviada para el documento ID: {$idDocumento}.</p>";
    } else {
        $mensaje = "<p style='color: red;'>❌ Error al enviar la solicitud.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<body>
    <h1>Panel de <?php echo htmlspecialchars($rol); ?></h1>
    <h2>Buscar Documento</h2>
    <?php echo $mensaje; ?>

    <form method="GET" action="secretaria.php">
        <input type="text" name="termino" placeholder="Buscar por título..." value="<?php echo htmlspecialchars($terminoBusqueda); ?>" required>
        <button type="submit">Buscar</button>
    </form>
    
    <?php if (!empty($documentos)): ?>
        <h3>Resultados de Búsqueda</h3>
        <table border="1">
            <thead>
                <tr>
                    <th>Título</th><th>Categoría</th><th>Subido por</th><th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($documentos as $doc): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($doc['titulo']); ?></td>
                        <td><?php echo htmlspecialchars($doc['categoria']); ?></td>
                        <td><?php echo htmlspecialchars($doc['usuarioSubio']); ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="idDocumento" value="<?php echo $doc['idDocumento']; ?>">
                                <button type="submit" name="solicitar_doc">Solicitar Documento</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (!empty($terminoBusqueda)): ?>
        <p>No se encontraron documentos.</p>
    <?php endif; ?>
    
    <p><a href="../logout.php">Cerrar Sesión</a></p>
</body>
</html>